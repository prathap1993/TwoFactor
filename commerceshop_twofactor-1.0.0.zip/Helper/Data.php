<?php
namespace Commerceshop\TwoFactor\Helper;
 

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    
   
}